#!/bin/bash

cd /etc/pki/tls/certs/
openssl req -x509 -nodes -newkey rsa:2048 -keyout ../private/apache.key -out apache.crt

