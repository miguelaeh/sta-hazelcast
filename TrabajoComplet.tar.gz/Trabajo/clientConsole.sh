#!/bin/sh

java -Djava.net.preferIPv4Stack=true -cp ./hazelcast-3.11/lib/hazelcast-all-3.11.jar com.hazelcast.client.console.ClientConsoleApp
