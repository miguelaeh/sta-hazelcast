#!/bin/bash

#Script que configura lo necesario para realizauna ejecución de tareas distribuidas en hazelcast mediante un executor service.

#instalamos maven que es necesario para ejecutar este ejemplo concreto
wget http://repos.fedorapeople.org/repos/dchen/apache-maven/epel-apache-maven.repo -O /etc/yum.repos.d/epel-apache-maven.repo
yum install apache-maven

#nos vamos al directorio donde esta el codigo
cd /home/dit/Trabajo/hazelcast-3.11/code-samples/
#construimos los ejecutables de los ejemplos con maven gracias al pom.xml que existe en esa carpeta.
mvn clean install

# ahora ya podemos irnos a ejecutar el script del ejemplo deseado
