#!/bin/sh

#______COMPILAMOS OPENJDK9_______

#descargamos e instalamos Mercurial, que es usado por openjdk para controlar los arboles de versiones, va tomando los ficheros necesarios de cada rama del arbol de versiones
yum install mercurial

#instalamos dependencias para evitar error de cabeceras X11 al ejecutar el script de configuracion
yum install libXtst-devel libXt-devel libXrender-devel libXi-devel
#instalamos dependencias para evitar error de cups no encontrados
yum install cups-devel
#para solucionar no podemos encontrar alsa
yum install alsa-lib-devel

#Clonamos los repositorios y obtenemos el código fuente necesario de cada repositorio con el script get_source
hg clone http://hg.openjdk.java.net/jdk9/jdk9
cd jdk9
bash get_source.sh

#ejecutamos el script de configuracion, creará una carpeta que sera $BUILD, y el árbol de directorios necesario y variables de entorno.
bash configure

#ejecutamos el makefile
make images

#verificamos que se ha instalado
./build/*/images/jdk/bin/java -version

#realizamos algunos test
make run-test-tier1





