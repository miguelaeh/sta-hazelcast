#!/bin/sh

#este script es una modificacion del script start.sh que nos propone hazelcast. He eliminado las comprobaciones de pid puesto este script
#lo ejecuto desde hazelcast (script de servicio) para que llame al ejecutable y esas comprobaciones ya las hago en hazelcast.
#Tambien se ha incluido a mano la ruta de HAZELCAST_HOME para que encuentre el ejecutable.
#El resto del script basicamente busca java en el equipo.

HAZELCAST_HOME=/home/dit/Trabajo/hazelcast-3.11/


if [ $JAVA_HOME ]
then
	echo "JAVA_HOME found at $JAVA_HOME"
	RUN_JAVA=$JAVA_HOME/bin/java
else
	echo "JAVA_HOME environment variable not available."
    RUN_JAVA=`which java 2>/dev/null`
fi

if [ -z $RUN_JAVA ]
then
    echo "JAVA could not be found in your system."
    echo "please install Java 1.6 or higher!!!"
    exit 1
fi

	echo "Path to Java : $RUN_JAVA"


if [ "x$MIN_HEAP_SIZE" != "x" ]; then
	JAVA_OPTS="$JAVA_OPTS -Xms${MIN_HEAP_SIZE}"
fi

if [ "x$MAX_HEAP_SIZE" != "x" ]; then
	JAVA_OPTS="$JAVA_OPTS -Xmx${MAX_HEAP_SIZE}"
fi

export CLASSPATH="$HAZELCAST_HOME/lib/hazelcast-all-3.11.jar:$HAZELCAST_HOME/user-lib:$HAZELCAST_HOME/user-lib/*"

echo "########################################"
echo "# RUN_JAVA=$RUN_JAVA"
echo "# JAVA_OPTS=$JAVA_OPTS"
echo "# starting now...."
echo "########################################"

#llamda al ejecutable de hazelcast, configurando los parametros necesarios y redireccionando la salida estandar y la de errores hacia /var/log/hazelcast
$RUN_JAVA -server $JAVA_OPTS -Dhazelcast.config=/home/dit/Trabajo/hazelcast.xml -Dhazelcast.diagnostics.directory=/home/dit/Trabajo/logs -Dhazelcast.diagnostics.enabled=true -Dhazelcast.diagnostics.metric.level=info -Dhazelcast.diagnostics.invocation.sample.period.seconds=30 -Dhazelcast.diagnostics.pending.invocations.period.seconds=30 -Dhazelcast.diagnostics.slowoperations.period.seconds=30 -Dhazelcast.diagnostics.storeLatency.period.seconds=60 com.hazelcast.core.server.StartServer &> /var/log/hazelcast &

#guardamos el pid en /var/run/$prog.pid
PID=$!
echo $PID > /var/run/${prog}.pid
   

