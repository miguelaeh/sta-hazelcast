#!/bin/bash

##cambiamos la jvm por la que hemos compilado jdk9
update-alternatives --install /usr/bin/java java /home/dit/Trabajo/jdk9/build/linux-x86_64-normal-server-release/jdk/bin/java 1000
update-alternatives --config java
