#!/bin/bash
#Descripcion: script que configura hazelcast como un servicio en el equipo, haciendo uso del script de servicio creado para ello hazelcast.sh.

#Ponermos el script de servicio en la carpeta init.d
rm -f /etc/rc.d/init.d/hazelcast
cp ./hazelcast /etc/rc.d/init.d/

#hacemos udo del comando chkconfig para crear los enlaces simbolicos.
chkconfig --add hazelcast

#configuramos los niveles de ejecucion en los que está activo, lo activaremos solo en el nivel 5.
chkconfig --level 1345 hazelcast on
chkconfig --level 026 hazelcast off

#cambiamos los permisos del script de servicio
chmod 755 /etc/rc.d/init.d/hazelcast


#ahora se puede arrancar hazelcast con service hazelcast start.

