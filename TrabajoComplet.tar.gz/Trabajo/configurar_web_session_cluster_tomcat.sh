#!/bin/bash

#Script para configurar el uso de hazelcast junto a tomcat como cluster de sesiones web.

#eliminamos los enlaces si los hay para refrescarlos por los ficheros nnuevos
rm -f /usr/share/tomcat/lib/hazelcast-all-3.11.jar
rm -f /usr/share/tomcat/lib/hazelcast-tomcat7-sessionmanager-1.1.3.jar
rm -f /usr/share/tomcat/lib/hazelcast.xml

#creamos enlaces simbolicos a los .jar necesarios en $CATALINA_HOME y al archivo de configracion de hazelcast para que lo utilice tomcat.
cp ./hazelcast-3.11/lib/hazelcast-all-3.11.jar /usr/share/tomcat/lib/
cp ./hazelcast-tomcat7-sessionmanager-1.1.3.jar /usr/share/tomcat/lib/
cp ./hazelcast-3.11/bin/hazelcast.xml /usr/share/tomcat/lib/

#cambiamos el archivo de configuracion de tomcat al mio que añade el listener para hazelcast.
cp ./server.xml /usr/share/tomcat/conf/

#cambiamos el archivo context.xml de tomcat por el mio que añade un manager para hazelcast
cp ./context.xml /usr/share/tomcat/conf/

#copiamos los ficheros con el balanceador de carga configurado en apache
rm -f /etc/httpd/conf.d/mod_jk_workers.properties
cp ./mod_jk_workers.properties /etc/httpd/conf.d/
rm -f /etc/httpd/conf.d/mod_jk.conf
cp ./mod_jk.conf /etc/httpd/conf.d/
rm -f /etc/tomcat/web.xml
cp ./web.xml /etc/tomcat/
rm -f /etc/httpd/conf/httpd.conf
cp ./httpd.conf /etc/httpd/conf/
cp ./mod_jk.so /etc/httpd/modules/mod_jk.so
#damos permisos a los archivos para que tomcat pueda usarlos y conectarse con el cluster
chmod 755 /usr/share/tomcat/lib/hazelcast-tomcat7-sessionmanager-1.1.3.jar
chmod 755 /usr/share/tomcat/lib/hazelcast-all-3.11.jar
chmod 644 /usr/share/tomcat/lib/hazelcast.xml
chmod 644 /etc/httpd/conf/httpd.conf
chmod 755 /etc/httpd/modules/mod_jk.so
#Ponemos el .war con la aplicacion web dentro de CATALINA_HOME/webapps ya que el server.xml tiene configurado eso como appBase.
cp ./httpSession.war /usr/share/tomcat/webapps/
chmod 744 /usr/share/tomcat/webapps/httpSession.war

#reiniciamos lo servidores
service tomcat restart
service httpd restart

